# Conjunto de Ícones — Vitryne

Conjunto completo de ícones gerados a partir do logotipo principal, prontos
para uso em **Web**, **iOS** e **Android**.

Todos os ícones usam o **"T" estilizado** da palavra VITRYNE (silhueta de
manequim/vitrine) como símbolo, sobre o roxo primário `#9530D9`.

---

## 📦 Estrutura

```
icones/
├── vitryne-icon.svg              ← Master vetorial (currentColor)
├── vitryne-icon-purple.svg       ← T roxo em fundo transparente
├── vitryne-icon-white.svg        ← T branco em fundo transparente
├── vitryne-icon-app.svg          ← Ícone completo (roxo + T branco)
├── vitryne-icon-rounded.svg      ← Ícone com cantos arredondados (PWA)
│
├── favicon.ico                   ← Favicon clássico multi-tamanho
├── favicon-16x16.png
├── favicon-32x32.png
├── favicon-48x48.png
├── favicon-dark-16.png           ← Versão dark (T claro em fundo escuro)
├── favicon-dark-32.png
│
├── apple-touch-icon.png          ← 180×180 padrão iOS
├── apple-touch-icon-120x120.png
├── apple-touch-icon-152x152.png
├── apple-touch-icon-167x167.png
├── apple-touch-icon-180x180.png
│
├── icon-72x72.png                ← PWA Android
├── icon-96x96.png
├── icon-128x128.png
├── icon-144x144.png
├── icon-152x152.png
├── icon-192x192.png              ← PWA recomendado
├── icon-384x384.png
├── icon-512x512.png              ← PWA splash
│
├── ios-app-icon-1024.png         ← App Store (1024×1024)
│
├── android-foreground.png        ← Camada de frente (T branco)
├── android-background.png        ← Camada de fundo (roxo sólido)
└── android-preview-composed.png  ← Preview do adaptive icon
```

---

## 🌐 Como usar na Web (React + Vite)

### 1. Copie os ícones para `public/`

```
vitryne-web/public/
├── favicon.ico
├── favicon-16x16.png
├── favicon-32x32.png
├── apple-touch-icon.png
├── icon-192x192.png
├── icon-512x512.png
└── manifest.webmanifest
```

### 2. No `index.html` (Vite usa esse arquivo na raiz)

```html
<!doctype html>
<html lang="pt-BR">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Vitryne — Moda da sua região</title>

    <!-- Favicon clássico (todos os browsers) -->
    <link rel="icon" href="/favicon.ico" sizes="any" />

    <!-- Favicon PNG (browsers modernos) -->
    <link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png" />
    <link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png" />

    <!-- iOS Safari (home screen) -->
    <link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png" />

    <!-- PWA -->
    <link rel="manifest" href="/manifest.webmanifest" />
    <meta name="theme-color" content="#9530D9" />
  </head>
  <body>
    <div id="root"></div>
    <script type="module" src="/src/main.tsx"></script>
  </body>
</html>
```

### 3. `public/manifest.webmanifest`

```json
{
  "name": "Vitryne",
  "short_name": "Vitryne",
  "description": "Marketplace de moda regional com delivery",
  "start_url": "/",
  "display": "standalone",
  "background_color": "#FFFFFF",
  "theme_color": "#9530D9",
  "icons": [
    {
      "src": "/icon-192x192.png",
      "sizes": "192x192",
      "type": "image/png",
      "purpose": "any maskable"
    },
    {
      "src": "/icon-512x512.png",
      "sizes": "512x512",
      "type": "image/png",
      "purpose": "any maskable"
    }
  ]
}
```

### 4. Usar o SVG inline em componentes React

Quando quiser o ícone do Vitryne dentro de um botão, header, etc:

```tsx
import VitryneIcon from './assets/vitryne-icon.svg?react';
// (Vite suporta importar SVG como componente com plugin vite-plugin-svgr)

<VitryneIcon style={{ width: 32, height: 32, color: '#9530D9' }} />
```

O `currentColor` no SVG faz ele herdar a cor do CSS — útil em dark mode.

---

## 📱 Como usar no Mobile (React Native + Expo)

### 1. Copie para `assets/`

```
vitryne-mobile/assets/
├── icon.png              ← cópia de ios-app-icon-1024.png (renomear)
├── adaptive-icon.png     ← cópia de android-foreground.png (renomear)
├── splash.png            ← cópia de icon-512x512.png (renomear)
└── favicon.png           ← cópia de favicon-48x48.png (renomear)
```

### 2. No `app.json` do Expo

```json
{
  "expo": {
    "name": "Vitryne",
    "slug": "vitryne",
    "version": "1.0.0",
    "icon": "./assets/icon.png",
    "splash": {
      "image": "./assets/splash.png",
      "resizeMode": "contain",
      "backgroundColor": "#9530D9"
    },
    "ios": {
      "supportsTablet": true,
      "bundleIdentifier": "app.vitryne"
    },
    "android": {
      "adaptiveIcon": {
        "foregroundImage": "./assets/adaptive-icon.png",
        "backgroundColor": "#9530D9"
      },
      "package": "app.vitryne"
    },
    "web": {
      "favicon": "./assets/favicon.png"
    }
  }
}
```

---

## 🎨 Especificações

| Propriedade | Valor |
|---|---|
| Cor primária | `#9530D9` |
| Cor do símbolo (sobre roxo) | `#FFFFFF` |
| Cor do símbolo (sobre claro) | `#9530D9` |
| Safe zone (Android adaptive) | 66% central do canvas |
| Padding interno (favicons) | 12-15% |
| Padding interno (apps) | 20-22% |

---

## ❓ Quando usar qual versão?

- **`vitryne-icon.svg`** (master) — quando quiser controlar a cor via CSS
- **`vitryne-icon-app.svg`** — para uso geral em UI (fundo roxo embutido)
- **`favicon.ico`** — sempre na raiz do site, todos os browsers reconhecem
- **`icon-192/512`** — PWA, splash screen, atalhos
- **`apple-touch-icon.png`** — quando alguém adicionar o site na tela inicial do iPhone
- **`ios-app-icon-1024.png`** — submeter na App Store
- **`android-foreground/background`** — submeter na Play Store

